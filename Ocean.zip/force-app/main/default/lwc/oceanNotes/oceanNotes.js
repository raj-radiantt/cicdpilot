import { LightningElement } from 'lwc';

export default class OceanNotes extends LightningElement {}