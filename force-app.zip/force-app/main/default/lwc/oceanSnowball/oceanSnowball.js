import { LightningElement } from 'lwc';

export default class OceanSnowball extends LightningElement {}