/* eslint-disable no-console */
import { LightningElement } from "lwc";

export default class Sidebar extends LightningElement {
    
}