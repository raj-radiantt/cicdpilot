import { LightningElement } from 'lwc';

export default class OceanBackupRequest extends LightningElement {}